import React, { Component } from 'react';
import AppContainer from './AppContainer';

class App extends Component {
  render() {
    return (
      <AppContainer />
    );
  }
}

export default App;
